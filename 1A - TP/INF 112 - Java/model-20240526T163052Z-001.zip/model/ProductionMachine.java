package fr.tp.inf112.robotsim.model;

public class ProductionMachine {

}
